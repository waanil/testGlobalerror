﻿using System;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Extensions.Logging;
using Serilog.Extensions.Hosting;
namespace ExtensionForSetup
{
    public static class Extension
    {
        public static IWebHostBuilder UseLoggig(this IWebHostBuilder webHostBuilder) =>
            webHostBuilder.UseSerilog((hostingContext, loggerConfiguration) => loggerConfiguration
        .ReadFrom.Configuration(hostingContext.Configuration).WriteTo.Console());


    }
}
