﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace ExtensionForSetup
{
    public class ExceptionHandlerMiddleware
    {
        private readonly RequestDelegate _next;
        ILogger _logger;

        public ExceptionHandlerMiddleware(RequestDelegate next)
        {
            _next = next;
            //_logger = logger;
        }

        public async Task Invoke(HttpContext httpContext, IHostingEnvironment hostingEnvironment, ILogger<ExceptionHandlerMiddleware> logger)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception e)
            {
                Log(httpContext, e, hostingEnvironment,logger);
                throw;
            }
        }

        private void Log(HttpContext context, Exception exception, IHostingEnvironment hostingEnvironment, ILogger<ExceptionHandlerMiddleware> logger)
        {
            logger.LogError(exception.ToString());
        }
    }
}
